from scraper import scrape


def main():
    scrape()


if __name__ == "__main__":
    main()
