import scraper


def main():
    scraper.main()


if __name__ == "__main__":
    main()
